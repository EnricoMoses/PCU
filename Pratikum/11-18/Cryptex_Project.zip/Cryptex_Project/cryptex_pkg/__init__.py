#TODO: import encrypt, decrypt, prepare_key
from .utils.key_manager import prepare_key
from .core.vigenere import encrypt, decrypt